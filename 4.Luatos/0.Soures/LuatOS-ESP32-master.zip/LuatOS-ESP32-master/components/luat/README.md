# Lua 虚拟机的源码

来源: 原版Lua 5.3.5, 含2020.12.31前已发布的官方修正

## 目录

```
inculde -- 头文件
modules -- Lua库的源码目录
rtt     -- rtt适配层
freertos -- freertos 适配层
```

